package com.cloudflare.manager.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cloudflare.manager.data.repository.AccountRepository
import com.cloudflare.manager.data.repository.DnsRepository
import com.cloudflare.manager.data.repository.ZoneRepository
import com.cloudflare.manager.domain.model.Account
import com.cloudflare.manager.domain.model.DnsRecord
import com.cloudflare.manager.domain.model.Zone
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DashboardUiState(
    val currentAccount: Account? = null,
    val accountCount: Int = 0,
    val zoneCount: Int = 0,
    val dnsCount: Int = 0,
    val zones: List<Zone> = emptyList(),
    val dnsRecords: List<DnsRecord> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null
)

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val accountRepository: AccountRepository,
    private val zoneRepository: ZoneRepository,
    private val dnsRepository: DnsRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState

    init {
        accountRepository.accounts
            .onEach { accounts ->
                _uiState.value = _uiState.value.copy(accountCount = accounts.size)
            }
            .launchIn(viewModelScope)

        accountRepository.currentAccount
            .onEach { current ->
                _uiState.value = _uiState.value.copy(currentAccount = current)
                if (current != null) {
                    loadDashboardData()
                }
            }
            .launchIn(viewModelScope)
    }

    fun loadDashboardData() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)
            try {
                val zonesResult = zoneRepository.listZones()
                val zones = zonesResult.getOrDefault(emptyList())
                _uiState.value = _uiState.value.copy(
                    zones = zones,
                    zoneCount = zones.size,
                    isLoading = false
                )

                val currentZone = zones.firstOrNull()
                if (currentZone != null) {
                    val dnsResult = dnsRepository.listRecords(currentZone.id)
                    val records = dnsResult.getOrDefault(emptyList())
                    _uiState.value = _uiState.value.copy(
                        dnsRecords = records,
                        dnsCount = records.size
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = e.message ?: "加载失败"
                )
            }
        }
    }
}
