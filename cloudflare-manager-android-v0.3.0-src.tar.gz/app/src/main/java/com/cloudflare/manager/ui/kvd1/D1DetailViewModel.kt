package com.cloudflare.manager.ui.kvd1

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cloudflare.manager.data.repository.AccountRepository
import com.cloudflare.manager.data.repository.CloudflareRepository
import com.cloudflare.manager.domain.model.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonElement
import javax.inject.Inject

data class D1DetailUiState(
    val databaseId: String = "",
    val databaseName: String = "",
    val sqlQuery: String = "",
    val queryState: UiState<List<Map<String, JsonElement>>> = UiState.Success(emptyList()),
    val isExecuting: Boolean = false,
    val message: String? = null
)

@HiltViewModel
class D1DetailViewModel @Inject constructor(
    private val accountRepository: AccountRepository,
    private val cloudflareRepository: CloudflareRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(D1DetailUiState())
    val uiState: StateFlow<D1DetailUiState> = _uiState

    private var accountId: String? = null

    fun setDatabase(databaseId: String, databaseName: String) {
        if (_uiState.value.databaseId == databaseId) return
        _uiState.value = _uiState.value.copy(
            databaseId = databaseId,
            databaseName = databaseName
        )
        viewModelScope.launch {
            accountId = accountRepository.getCurrentAccount()?.accountId
        }
    }

    fun onSqlChange(sql: String) {
        _uiState.value = _uiState.value.copy(sqlQuery = sql)
    }

    fun executeQuery() {
        val id = accountId ?: return
        val dbId = _uiState.value.databaseId
        val sql = _uiState.value.sqlQuery.trim()
        if (sql.isBlank()) return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isExecuting = true,
                queryState = UiState.Loading
            )
            val result = cloudflareRepository.queryD1(id, dbId, sql)
            _uiState.value = _uiState.value.copy(
                isExecuting = false,
                queryState = result.fold(
                    onSuccess = { UiState.Success(it) },
                    onFailure = { UiState.Error(it.message ?: "查询失败") }
                ),
                message = if (result.isSuccess) "查询成功" else (result.exceptionOrNull()?.message ?: "查询失败")
            )
        }
    }

    fun clearMessage() {
        _uiState.value = _uiState.value.copy(message = null)
    }
}
